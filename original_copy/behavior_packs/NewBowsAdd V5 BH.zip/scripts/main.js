import { system, world } from "@minecraft/server";

//Loop Events

world.events.tick.subscribe(() =>{
    let w = world.getDimension("overworld"); 

    for (let p of world.getPlayers()) {
        p.runCommandAsync(`function inventory`)
    }
});

world.events.blockPlace.subscribe((blockPlace) =>{
   let block = blockPlace.block;
   let player = blockPlace.player;

   let blockLocation = [
        blockPlace.block.location.x,
        blockPlace.block.location.y,
        blockPlace.block.location.z

     ];

     if(block.typeId == "minecraft:fletching_table"){
       player.runCommandAsync(`setblock ${blockLocation[0]} ${blockLocation[1]} ${blockLocation[2]} new:bow_table 0`)
     }

});