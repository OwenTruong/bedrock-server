import { world, Location } from "@minecraft/server"
import { system } from "@minecraft/server";
import { ActionFormData, MessageFormData, ModalFormData } from "@minecraft/server-ui"

system.events.beforeWatchdogTerminate.subscribe(data => {
  data.cancel = true;
});
const DimensionNames = {
  ["minecraft:overworld"]: "§aOverworld",
  ["minecraft:nether"]: "§cNether",
  ["minecraft:the_end"]: "§dEnd"
};
function onPlayerDeath() {
    let players = world.getPlayers()
    for (let player of players) {
      let playerHealt = player.getComponent("minecraft:health").current
      let isDeath = player.hasTag("death")
      let Dimension = world.getDimension(player.dimension.id)
      if (playerHealt == 0 && isDeath == false) {
        const dName = DimensionNames[player.dimension.id];
        player.addTag("lol")
        player.addTag("death")
        let entity = Dimension.spawnEntity("pog:player_corpse", new Location(player.location.x, player.location.y, player.location.z));
        entity.nameTag = "Corpse of " + player.name;
        player.runCommandAsync(`tellraw @s{"rawtext":[{"text": "§a${player.nameTag} §rdied at: §b${Math.round(player.location.x)}, ${Math.round(player.location.y)}, ${Math.round(player.location.z)},§r§f in The §a${dName}"}]}`)
      } else if (playerHealt > 0) {
        player.removeTag("death")
      } 
  }
  }


  world.events.tick.subscribe(onPlayerDeath)
  world.events.entityHit.subscribe(data => {
      let { entity } = data
if(data.hitEntity?.typeId == 'pog:player_corpse'){
  bounty_tier_page(entity)
    }})

    function bounty_tier_page(entity) {
      let form = new ActionFormData()
        form.title("Are You Sure?")
        form.body("You are about to turn your corpse into ashes.\n\nIf you decide to turn your corpse into ash, all stored items will be lost.")
        ///buttons
        form.button("Dust")
        form.button("Spare")
        form.show(entity).then((response) => {
          if (response.selection == 0) {
            
            world.getDimension('overworld').runCommandAsync('function despawn_corpse_in_radius')
            console.warn("Dust")
          }
          if (response.selection == 1) {
            console.warn("Spare")
          }
        })
    }
  